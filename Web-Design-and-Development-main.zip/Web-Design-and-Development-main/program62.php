<?php
$vals=[1.65,1.65,-1.54];
foreach($vals as $v) echo round($v,1)."\n";
?>