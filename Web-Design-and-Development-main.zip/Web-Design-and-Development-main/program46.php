<?php
$arr = [10,20,30];
$index = array_search(20, $arr);
echo $index; // 1
?>