<?php
function average($arr){
  return array_sum($arr)/count($arr);
}
?>