<?php
$matrix = [
  [1,2,3],
  [4,5,6],
  [7,8,9]
];
echo $matrix[1][2]; // 6 (2nd row, 3rd column)
?>