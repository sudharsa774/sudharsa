<?php
$arr = ["One","Two","Three"];
print_r(array_map('strtolower',$arr));
print_r(array_map('strtoupper',$arr));
?>