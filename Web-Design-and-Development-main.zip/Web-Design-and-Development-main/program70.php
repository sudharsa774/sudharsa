<?php
$input = readline("Enter numbers separated by space: ");
$nums = explode(" ", $input);
print_r($nums);
?>