<?php
$x = [1,2,3,4,5];
unset($x[2]);
print_r($x);
?>