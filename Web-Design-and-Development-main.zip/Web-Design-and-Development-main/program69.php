<?php
$Color = ['A'=>'Blue','B'=>'Green','c'=>'Red'];
print_r(array_map('strtolower',$Color));
print_r(array_map('strtoupper',$Color));
?>