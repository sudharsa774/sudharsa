<?php
$arr = ['A'=>1,'B'=>2];
if(in_array(2,$arr)) echo "Found";
?>