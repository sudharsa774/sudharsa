<?php
$arr = [1,2,3];
$i = 0;
while ($i < count($arr)) {
  echo $arr[$i] . " ";
  $i++;
}
?>