<?php
$arr = [10, 20, 30, 40];
array_shift($arr);
print_r($arr);  // [20, 30, 40]
?>