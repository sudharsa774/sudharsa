<?php
$str = "Hello world";
$find = "world";
if (strpos($str, $find) !== false)
    echo "Found";
else
    echo "Not found";
?>