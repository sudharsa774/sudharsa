<?php
$fruits = ["Apple", "Banana", "Mango", "Orange"];
echo $fruits[2]; // Mango
?>