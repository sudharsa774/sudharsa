<?php
$arr=[1,2,3];
array_pop($arr); // removes 3
array_shift($arr); // removes 1
?>